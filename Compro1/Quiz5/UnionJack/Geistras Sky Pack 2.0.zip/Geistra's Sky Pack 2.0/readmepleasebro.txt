Hi! 

Thanks for downloading Sky Pack 2.0! If you don't know how to install an icon pack properly, read below. If you do, then I'm happy to finally be able to do this for everyone. Took a while to get everything in 1 pack together. I won't be releasing stuff separately anymore. It gets too confusing, even for me lol.
I will try for now on to release all DLC packs the day of DLC release. Unless ofc I'm not around my computer. I hope you guys enjoy this. It contains everything from release to now (Chapter Oni).

To install: Go to your DbD directory in steam. Click Properties, Local Files, Browse Local Files. Then click Dead By Daylight, DeadByDaylight, Content, UI, Icons. From there, go into the folders where the packs belong, drag and drop, hit replace, gg.
No, you won't get banned unless EAC decides to ban for it, which they said they won't. And if they did, word would get out and I would make sure to tweet it out saying to get rid of the icons.

ON THAT NOTE, if you want to get rid of the pack, all you need to do is right click Dead By Daylight, Properties, hit Verify Integrity, wait for all the files to be verified, and they'll be removed. It's that simple! 


































ᵢ'ₘ 𝓰ₐᵧ ᵤ𝓌ᵤ